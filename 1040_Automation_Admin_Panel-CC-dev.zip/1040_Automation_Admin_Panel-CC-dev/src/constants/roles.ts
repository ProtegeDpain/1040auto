export const ROLES = {
    ADMIN: 1,
    USER: 2,
}
