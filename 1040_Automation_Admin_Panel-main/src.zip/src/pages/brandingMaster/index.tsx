// app/users/create/page.tsx  OR  pages/users/create.tsx

const ClientRegistration = () => {

  return (
    <div className="min-h-screen px-8 py-12 bg-gray-50">
        
    </div>
  );
};

export default ClientRegistration;
