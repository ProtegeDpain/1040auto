export default function Feed() {
  return <div></div>;
}
